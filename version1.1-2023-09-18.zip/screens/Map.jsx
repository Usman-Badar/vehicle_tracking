import 'react-native-get-random-values';
import React, { useEffect, useState } from 'react';
import MapView, { Polyline, Marker, Circle } from 'react-native-maps';
import { StyleSheet, View, TouchableOpacity, Text, ToastAndroid, Alert } from 'react-native';
import * as Location from 'expo-location';
import moment from 'moment';
import axios from '../axios';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { v4 as uuidv4 } from 'uuid';
import * as Speech from 'expo-speech';

const Map = ({ navigation }) => {
    const TrackingDirectory = FileSystem.documentDirectory + '/tracking_history';
    const MobileDirectory = FileSystem.documentDirectory + '/tracking_mobile';
    const HistoryFile = TrackingDirectory + '/history.txt';
    const MobileFile = MobileDirectory + '/mobile.txt';
    
    const [subscription, setSubscription] = useState();
    const [distance, setDistance] = useState(null);
    const [reachedAtAStation, setReachedAtAStation] = useState(null);
    const [nextStation, setNextStation] = useState();
    const [userInfo, setUserInfo] = useState();
    const [stops, setStops] = useState([]);
    const [location, setLocation] = useState(null);
    const [started, setStarted] = useState(false);
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [coordinates, setCoordinates] = useState([]);

    useEffect(() => {
        (async () => {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                alert('Permission to access location was denied');
                return;
            }

            const location = await Location.getCurrentPositionAsync({});
            setLocation(location);
            getMobile();
            create();
        })();
    }, []);
    useEffect(() => {
        if (started) {
            watchLocation();
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.017373749011337, longitude: 67.03033179067538 }}]);
            // }, 100000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.01106717159305, longitude: 67.03880866699181 }}]);
            // }, 95000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.004877122612516, longitude: 67.04143520799495 }}]);
            // }, 90000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00318471757926, longitude: 67.04195097261106 }}]);
            // }, 85000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.002894588661146, longitude: 67.04248452221391 }}]);
            // }, 80000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00352320045111, longitude: 67.0445031182114 }}]);
            // }, 75000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.004940167391638, longitude: 67.04867741617186 }}]);
            // }, 70000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00576342488896, longitude: 67.05148576998138 }}]);
            // }, 65000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00578901048269, longitude: 67.05334201783381 }}]);
            // }, 60000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.005840181654214, longitude: 67.05409016335608 }}]);
            // }, 55000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00598090226591, longitude: 67.05579113572277 }}]);
            // }, 50000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.006230361149186, longitude: 67.06155044479937 }}]);
            // }, 45000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00639666677728, longitude: 67.06292675026336 }}]);
            // }, 40000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00638387404436, longitude: 67.06402073664026 }}]);
            // }, 35000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.005948920332255, longitude: 67.06430305570527 }}]);
            // }, 35000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00216048842225, longitude: 67.06481789312207 }}]);
            // }, 30000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00120260779875, longitude: 67.06453313792468 }}]);
            // }, 25000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00091803228071, longitude: 67.06464047567509 }}]);
            // }, 20000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 25.00009152752843, longitude: 67.06489796767686 }}]);
            // }, 15000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 24.99979981864141, longitude: 67.06467266217531 }}]);
            // }, 10000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 24.998705904104387, longitude: 67.06497306951339 }}]);
            // }, 5000);
            // setTimeout(() => {
            //     setCoordinates((coords) => [...coords, {coords: { latitude: 24.986998121163452, longitude: 67.06550745342014 }}]);
            // }, 2000);
        }
    }, [started]);
    useEffect(() => {
        if (coordinates.length > 0 && started) {
            saveInFile();
            let arr = stops.slice();
            arr.map((val) => {
                const { coords } = coordinates.slice(-1)[0];
                const distance = calcCrow(parseFloat(coords.latitude), parseFloat(coords.longitude), parseFloat(val.latitude), parseFloat(val.longitude));
                val.distance = distance;
                return val;
            });
            const min = Math.min(...arr.map(item => item.distance));
            const theNextStation = arr.find(obj => {return obj.distance === min});
            if (!nextStation && theNextStation) {
                Speech.speak(`The Next station is. ${theNextStation.stop_name}`, { rate: 0.9, pitch: 0.7 });
                setStops(arr);
            }else if (nextStation && theNextStation && nextStation.stop_name !== theNextStation.stop_name) {
                Speech.speak(`The Next station is. ${theNextStation.stop_name}`, { rate: 0.9, pitch: 0.7 });
            }
            if (theNextStation) {
                setNextStation(theNextStation);
                setDistance(parseFloat(theNextStation.distance));
            }
        }
    }, [coordinates]);
    useEffect(() => {
        if (distance && started) {
            // 0.0499 original distance
            if (distance < 0.0499 && reachedAtAStation === null && nextStation) {
                setReachedAtAStation(nextStation.stop_id);
            }else if (distance > 0.0499 && reachedAtAStation !== null && nextStation) {
                moveFromAStation();
            }
        }
    }, [distance]);
    useEffect(() => {
        if (reachedAtAStation && nextStation) {
            stationReached(nextStation);
        }
    }, [reachedAtAStation]);

    const moveFromAStation = () => {
        const currentDate = new Date().toISOString().slice(0, 10).replace('T', ' ');
        FileSystem.readAsStringAsync(HistoryFile, { encoding: FileSystem.EncodingType.UTF8 }).then(data => {
            const data_found = JSON.parse(data);
            if(data_found.length > 0) {
                data_found.map((obj) => {
                    if (obj && obj.date === currentDate && obj.endTime === '') {
                        obj.stopsReached.map(
                            station => {
                                if (parseInt(station.stop_id) === parseInt(reachedAtAStation)) {
                                    station.moveTime = new Date().toTimeString();
                                }
                                return station;
                            }
                        )
                    };
                    return obj;
                });
                const stations = stops.slice().filter(obj => {return parseInt(obj.stop_id) !== parseInt(reachedAtAStation)});
                if (stations.length > 0) {
                    setStops(() => stations);
                }else {
                    setStops(() => []);
                    setNextStation(null);
                }
                setReachedAtAStation(null);
                update(data_found);
            }
        }).catch((err) => {
            console.log("Err Found1:", err);
            create();
        });
    }
    const stationReached = (station) => {
        Speech.speak(station.stop_name, { rate: 0.9, pitch: 0.7 });
        const currentDate = new Date().toISOString().slice(0, 10).replace('T', ' ');
        FileSystem.readAsStringAsync(HistoryFile, { encoding: FileSystem.EncodingType.UTF8 }).then(data => {
            const data_found = JSON.parse(data);
            if (data_found.length > 0) {
                data_found.map((obj) => {
                    if (obj && obj.date === currentDate && obj.endTime === '') {
                        if (obj.stopsReached) {
                            obj.stopsReached.push(
                                {
                                    stop_id: station.stop_id,
                                    stop_name: station.stop_name,
                                    timeReached: new Date().toTimeString()
                                }
                            );
                        }else {
                            obj.stopsReached = [
                                {
                                    stop_id: station.stop_id,
                                    stop_name: station.stop_name,
                                    timeReached: new Date().toTimeString()
                                }
                            ];
                        }
                    };
                    return obj;
                });
            }
            update(data_found);
        }).catch((err) => {
            console.log("Err Found2:", err.stack);
            create();
        });
    }
    const checkIfThePreviousTrackingWasEnded = () => {
        const currentDate = new Date().toISOString().slice(0, 10).replace('T', ' ');
        FileSystem.readAsStringAsync(HistoryFile, { encoding: FileSystem.EncodingType.UTF8 }).then(data => {
            const data_found = JSON.parse(data);
            if(data_found.length > 0) {
                let objData;
                data_found.map((obj) => {
                    if (obj && obj.date === currentDate && obj.endTime === '') {
                        objData = obj;
                    };
                    return obj;
                });
                if (objData) {
                    ToastAndroid.show('Tracking Continue...', ToastAndroid.SHORT);
                    continuePreviousTracking(objData);
                }
            }
        }).catch((err) => {
            console.log("Err Found3:", err);
            create();
        });
    }
    const fetchRoute = (id) => {
        ToastAndroid.show('Fetching Your Route', ToastAndroid.SHORT);
        axios.post('/vehicle/tracking/route', {mobile_id: id}).then(({data}) => {
            setStops(data[0]);
            if (!userInfo) setUserInfo({mobile_id: id, route_id: data[1].route_id});
        }).catch(err => {
            console.log(err);
            Alert.alert("Err2", "Application error found:" + err, [ {text: "Retry", onPress: () => fetchRoute(id)}, {text: 'Close'} ])
        });
    }
    const getMobile = async () => {
        ToastAndroid.show('Getting Your ID', ToastAndroid.SHORT);
        FileSystem.readAsStringAsync(MobileFile, { encoding: FileSystem.EncodingType.UTF8 }).then(
            data => {
                const id = data;
                fetchRoute(id);
                // checkIfThePreviousTrackingWasEnded();
            }
        ).catch(err => {
            console.log(err);
            Alert.alert("Err1", "Application error found:" + err, [ {text: "Retry", onPress: () => getMobile()}, {text: 'Close'} ])
        });
    }
    const watchLocation = async () => {
        let watcher = await Location.watchPositionAsync({accuracy: Location.Accuracy.Balanced, timeInterval: 1000, distanceInterval: 1}, (current_location) => {
            if (started) {
                if (current_location.coords.speed < 1) {
                    current_location.strokeColor = '#dc3545';
                }else if (current_location.coords.speed > 30) {
                    current_location.strokeColor = '#28a744';
                }
                setCoordinates((coords) => [...coords, current_location]);
                setLocation(current_location);
                setSubscription(watcher);
            }
        });
    }
    const getDuration = () => {
        const startingTime = moment(startTime, 'HH:mm:ss a');
        const endingTime = endTime.length > 0 ? moment(endTime, 'HH:mm:ss a') : moment(new Date().toTimeString(), 'HH:mm:ss a');
        const duration = moment.duration(endingTime.diff(startingTime));
        const hours = parseInt(duration.asHours());
        const minutes = parseInt(duration.asMinutes()) % 60;
        return `${hours}:${minutes}`;
    }
    const saveInFile = async () => {
        const currentDate = new Date().toISOString().slice(0, 10).replace('T', ' ');
        FileSystem.readAsStringAsync(HistoryFile, { encoding: FileSystem.EncodingType.UTF8 }).then(data => {
            const data_found = JSON.parse(data);
            if(data_found.length > 0) {
                data_found.map((obj) => {
                    if (obj && obj.date === currentDate && obj.endTime === '') {
                        obj.coordinates = coordinates
                    };
                    return obj;
                });
            }else {
                data_found.push(
                    {
                        id: uuidv4(),
                        userInfo: userInfo,
                        startTime: startTime,
                        endTime: endTime,
                        date: currentDate,
                        coordinates: coordinates
                    }
                );
            }
            update(data_found);
        }).catch((err) => {
            console.log("Err Found4:", err);
            create();
        });
    }
    const update = async (data_found) => {
        console.log('updated', new Date().toLocaleTimeString());
        await FileSystem.writeAsStringAsync(HistoryFile, JSON.stringify(data_found), { encoding: FileSystem.EncodingType.UTF8 });
    }
    const create = async () => {
        const fileExists = await FileSystem.getInfoAsync(HistoryFile);
        if (!fileExists.exists) {
            await FileSystem.makeDirectoryAsync(TrackingDirectory, { intermediates: true });
            FileSystem.writeAsStringAsync(HistoryFile, JSON.stringify([]), { encoding: FileSystem.EncodingType.UTF8 }).then(() => {
                    console.log("File has been created");
            }).catch(
                err => {
                    Alert.alert('error while creating file', err.message);
                }
            )
        }
    }
    const start = () => {
        setStarted(true);
        setStartTime(new Date().toTimeString());
        ToastAndroid.show('Tracking Started', ToastAndroid.SHORT);
    }
    const end = async () => {
        const currentDate = new Date().toISOString().slice(0, 10).replace('T', ' ');
        const endingTime = new Date().toTimeString();
        subscription?.remove();
        ToastAndroid.show('Tracking Ended', ToastAndroid.SHORT);
        setEndTime(endingTime);
        FileSystem.readAsStringAsync(HistoryFile, { encoding: FileSystem.EncodingType.UTF8 }).then(data => {
            const data_found = JSON.parse(data);
            data_found.map((obj) => {
                if (obj && obj.date === currentDate && obj.endTime === '') {
                    obj.endTime = endingTime;
                    updateOnLive(obj);
                }
                return obj;
            });
        }).catch((err) => {
            console.log("Err Found5:", err);
            create();
        });
    }
    const saveData = async (data_found) => {
        await FileSystem.writeAsStringAsync(HistoryFile, JSON.stringify(data_found), { encoding: FileSystem.EncodingType.UTF8 });
        ToastAndroid.show('Saved', ToastAndroid.SHORT);
        // navigation.navigate('History');
    }
    const updateOnLive = (obj) => {
        setStarted(false);
        ToastAndroid.show('Updating on live', ToastAndroid.SHORT);
        axios.post('/vehicle/tracking/save', {data: JSON.stringify(obj)}).then(() => {
            setStartTime('');
            setEndTime('');
            setCoordinates([]);
            getLocation();
            axios.post('/vehicle/tracking/route', {mobile_id: userInfo.mobile_id}).then(({data}) => {
                setStops(data[0]);
                Alert.alert("Tracking Saved", "Your route track logs has been updated on live.", [{text: "Okay", onPress: () => removeFile()}]);
            }).catch(err => console.log(err));
        }).catch(err => {
            setStarted(true);
            console.log(err);
            Alert.alert("Err1", "Application error found:" + err, [ {text: "Retry", onPress: () => updateOnLive(obj)}, {text: 'Close'} ])
        });
    }
    const getLocation = async () => {
        const location = await Location.getCurrentPositionAsync({});
        setLocation(location);
        fetchRoute(userInfo.mobile_id);
    }
    const removeFile = async () => {
        await FileSystem.deleteAsync(HistoryFile);
        create();
        console.log("File deleted successfully");
    }
    const continuePreviousTracking = (data) => {
        const { startTime, coordinates } = data;
        setStarted(true);
        setStartTime(startTime);
        setCoordinates(coordinates);
    }
    function toRad(Value) {
        return Value * Math.PI / 180;
    }
    function calcCrow(lat1, lon1, lat2, lon2) {
        var R = 6371; // km
        var dLat = toRad(lat2 - lat1);
        var dLon = toRad(lon2 - lon1);
        var lat1 = toRad(lat1);
        var lat2 = toRad(lat2);

        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c;
        return d;
    }
    function convertInKm(coords) {
        return ((coords * 3600) / 1000).toFixed(2);
    }
    if(!userInfo) {
        return <Text style={{textAlign: 'center', paddingTop: 50}}>Getting Your ID....</Text>;
    }
    return (
        <View style={styles.container}>
            {
                location && userInfo && userInfo.mobile_id && userInfo.route_id
                ?
                <View style={{flex: 1}}>
                    <View style={{height: 50, backgroundColor: '#3c99d4',alignItems: 'center', justifyContent: 'center'}}>
                        <Text style={{color: "#fff", fontSize: 18, textAlign: 'center'}}>Live Vehicle Tracking</Text>
                    </View>
                    <MapView style={styles.map}
                        // minZoomLevel={15}
                        paddingAdjustmentBehavior="automatic"
                        initialRegion={
                            {
                                latitude: location.coords?.latitude,
                                longitude: location.coords?.longitude,
                                latitudeDelta: 0.0922,
                                longitudeDelta: 0.0421,
                            }
                        }
                        mapType='hybrid'
                        userInterfaceStyle="dark"
                        userLocationPriority="high"
                        followsUserLocation
                        showsUserLocation
                        loadingEnabled
                        fitToElements
                        // showsTraffic
                    >
                        <Polyline
                            coordinates={coordinates.map(({coords}) => {return coords})}
                            strokeColor='#3296ff'
                            strokeWidth={5}
                        />
                        {
                            nextStation
                            ?
                            <View>
                                <Marker
                                    coordinate={{ latitude: nextStation.latitude, longitude: nextStation.longitude }}
                                    title={nextStation.stop_name}
                                    description='Next Station'
                                />
                                <Circle
                                    center={{ latitude: nextStation.latitude, longitude: nextStation.longitude }}
                                    strokeColor={'#E99A28'}
                                    strokeWidth={2}
                                    fillColor={'rgba(37, 55, 84, 0.2)'}
                                    radius={50}
                                />
                            </View>
                            :null
                        }
                        {
                            stops.map(
                                ({ stop_name, latitude, longitude }, i) => {
                                    return (
                                        <View key={i}>
                                            <Marker
                                                coordinate={{ latitude: latitude, longitude: longitude }}
                                                title={stop_name}
                                                description='Station'
                                            />
                                            <Circle
                                                center={{ latitude: latitude, longitude: longitude }}
                                                strokeColor={'#E99A28'}
                                                strokeWidth={2}
                                                fillColor={'rgba(37, 55, 84, 0.2)'}
                                                radius={50}
                                            />
                                        </View>
                                    )
                                }
                            )
                        }
                    </MapView>
                    <View style={styles.controls}>
                        {
                            started
                            ?
                            <View>
                                <View style={{display: 'flex', flexDirection: "row", justifyContent: 'space-between', borderBottomColor: "#000", borderBottomWidth: 1, marginBottom: 5}}>
                                    <Text>Speed km/h</Text>
                                    <Text>{convertInKm(coordinates.slice(-1)[0]?.coords?.speed)}</Text>
                                </View>
                                <View style={{display: 'flex', flexDirection: "row", justifyContent: 'space-between', borderBottomColor: "#000", borderBottomWidth: 1, marginBottom: 5}}>
                                    <Text>Hour(s)</Text>
                                    <Text>{startTime ? getDuration() : "..."}</Text>
                                </View>
                                {
                                    endTime.length > 0
                                    ?
                                    <View style={{display: 'flex', flexDirection: "row", justifyContent: 'space-between', borderBottomColor: "#000", borderBottomWidth: 1, marginBottom: 5}}>
                                        <Text>End Time</Text>
                                        <Text>{endTime !== '' ? moment(endTime, 'HH:mm:ss a').format('HH:mm A') : null}</Text>
                                    </View>
                                    :null
                                }
                                <View style={{display: 'flex', flexDirection: "row", justifyContent: 'space-between', borderBottomColor: "#000", borderBottomWidth: 1, marginBottom: 5}}>
                                    <Text>Start Time</Text>
                                    <Text>{startTime !== '' ? moment(startTime, 'HH:mm:ss a').format('HH:mm A') : null}</Text>
                                </View>
                                <TouchableOpacity style={[ styles.btn, { backgroundColor: '#ee4a2f', marginTop: 10 } ]} onPress={end}>
                                    <Text style={styles.btnText}>End</Text>
                                </TouchableOpacity>
                            </View>
                            :
                            <View style={{display: 'flex', flexDirection: 'row', justifyContent: 'space-around'}}>
                                <TouchableOpacity style={[styles.btn, {width: '45%'}]} onPress={start}>
                                    <Text style={styles.btnText}>Start</Text>
                                </TouchableOpacity>
                                <TouchableOpacity onPress={() => navigation.navigate('History')} style={[styles.btn, {width: '45%', backgroundColor: '#ee4a2f'}]}>
                                    <Text style={styles.btnText}>History</Text>
                                </TouchableOpacity>
                            </View>
                        }
                    </View>
                </View>
                :
                <Text style={{textAlign: 'center', paddingTop: 30}}>Finding your coordinates...</Text>
            }
        </View>
    )
}

export default Map;

const styles = StyleSheet.create({
    container: {
        paddingTop: 30,
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative'
    },
    controls: {
        padding: 10
    },
    btn: {
        padding: 15,
        backgroundColor: "#3c99d4",
        borderRadius: 5,
    },
    btnText: {
        textAlign: "center",
        color: "#fff"
    },
    map: {
        flex: 1,
        minHeight: '50%'
    },
});