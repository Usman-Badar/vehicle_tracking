import React from 'react';
import { View } from 'react-native';

const ErrorPage = () => {
    return (
        <View>
            
        </View>
    )
}

export default ErrorPage;